<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\ImageUploadController;
use App\Http\Controllers\ImageGalleryController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

Route::get('login', [AuthController::class, 'index'])->name('login');
Route::post('post-login', [AuthController::class, 'postLogin'])->name('login.post'); 
Route::get('registration', [AuthController::class, 'registration'])->name('register');
Route::post('post-registration', [AuthController::class, 'postRegistration'])->name('register.post'); 

Route::get('registration1', [AuthController::class, 'registration1'])->name('register1');
Route::post('post-registration1', [AuthController::class, 'postRegistration1'])->name('register1.post'); 

Route::get('dashboard', [AuthController::class, 'dashboard']); 
Route::get('logout', [AuthController::class, 'logout'])->name('logout');

//Route::get('image-gallery', 'ImageGalleryController@index');
//Route::post('image-gallery', 'ImageGalleryController@upload');
//Route::delete('image-gallery/{id}', 'ImageGalleryController@destroy');

Route::get('image-gallery', [ImageGalleryController::class, 'index']); 
Route::post('image-gallery', [ImageGalleryController::class, 'upload']); 
Route::post('image-gallery/{id}', [ImageGalleryController::class, 'destroy']); 
